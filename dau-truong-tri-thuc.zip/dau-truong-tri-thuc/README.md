# Đấu Trường Tri Thức – Lịch sử Tây Ninh

Website game show trắc nghiệm gồm 4 vòng, mỗi vòng 10 câu hỏi (40 câu).

## Chạy thử
Mở `index.html` bằng trình duyệt. Không cần cài đặt.

## Đưa lên GitHub Pages
1. Tạo repository GitHub mới.
2. Tải toàn bộ file trong thư mục này lên repository (giữ nguyên tên file).
3. Vào **Settings → Pages**.
4. Ở **Build and deployment**, chọn **Deploy from a branch**.
5. Chọn nhánh `main`, thư mục `/ (root)`, nhấn **Save**.
6. Đợi GitHub tạo đường dẫn website trong mục Pages.

## Tài khoản MC / Admin
- Tên đăng nhập: `admin`
- Mật khẩu: `tayninh2026`

## Tính năng
- Giao diện đăng nhập thí sinh.
- 4 vòng thi, 10 câu mỗi vòng.
- Trắc nghiệm 4 lựa chọn, chấm điểm tự động (10 điểm/câu đúng).
- Bảng điều khiển MC/Admin xem câu hỏi và đáp án đúng.
- Trang tổng kết điểm và chơi lại.

## Lưu ý
Đây là bản frontend tĩnh phù hợp GitHub Pages. Đăng nhập admin chỉ là lớp giao diện phía trình duyệt, không bảo mật cho dữ liệu nhạy cảm. Điểm số không đồng bộ giữa nhiều thiết bị. Nếu cần tài khoản thật, bảng xếp hạng trực tuyến hoặc MC điều khiển câu hỏi đồng thời cho nhiều thí sinh, cần bổ sung backend/cơ sở dữ liệu.
