const $=id=>document.getElementById(id);
let player={name:"",team:""},round=0,qIndex=0,score=0,answered=false,done=0;
const views=["loginView","gameView","resultView","adminView"];
function show(id){views.forEach(v=>$(v).classList.toggle("hidden",v!==id));window.scrollTo(0,0)}
function renderTabs(){ $("roundTabs").innerHTML=QUIZ.map((r,i)=>`<div class="round-tab ${i===round?'active':''} ${i<round?'done':''}">${i<round?'✓ ':''}${r.name.toUpperCase()}</div>`).join("")}
function renderQuestion(){
 const q=QUIZ[round].questions[qIndex];answered=false;
 $("roundLabel").textContent=`VÒNG ${round+1} · ${QUIZ[round].name.split("·")[1].trim().toUpperCase()}`;
 $("questionCount").textContent=`CÂU ${String(qIndex+1).padStart(2,"0")} / 10`;
 $("topicLabel").textContent=QUIZ[round].topic;
 $("questionText").textContent=q[0];
 $("progressBar").style.width=`${(qIndex+1)*10}%`;
 $("answers").innerHTML=q[1].map((a,i)=>`<button class="answer" data-index="${i}"><span class="letter">${"ABCD"[i]}</span>${a}</button>`).join("");
 [...$("answers").children].forEach(btn=>btn.addEventListener("click",()=>choose(Number(btn.dataset.index))));
 $("feedback").textContent="Chọn một đáp án chính xác nhất.";
 $("nextBtn").disabled=true;$("nextBtn").textContent=qIndex===9&&round===3?"XEM KẾT QUẢ →":"CÂU TIẾP THEO →";
 $("roundProgress").textContent=`${qIndex+(answered?1:0)}/10`;$("totalDone").textContent=`${done}/40`;
 renderTabs();
}
function choose(index){
 if(answered)return;answered=true;const q=QUIZ[round].questions[qIndex],correct=q[2];
 [...$("answers").children].forEach((b,i)=>{b.disabled=true;if(i===correct)b.classList.add("correct");if(i===index&&i!==correct)b.classList.add("wrong")});
 if(index===correct){score+=10;$("feedback").textContent="Chính xác! Bạn nhận được 10 điểm."; $("feedback").style.color="var(--green)"}else{$("feedback").textContent=`Chưa chính xác. Đáp án đúng: ${"ABCD"[correct]}. ${q[1][correct]}`;$("feedback").style.color="var(--red)"}
 done++;$("score").textContent=score;$("roundProgress").textContent=`${qIndex+1}/10`;$("totalDone").textContent=`${done}/40`;$("nextBtn").disabled=false;
}
function next(){
 if(!answered)return;
 if(qIndex<9)qIndex++;else if(round<3){round++;qIndex=0}else{finish();return}
 renderQuestion();
}
function start(){player.name=$("playerName").value.trim();player.team=$("playerClass").value.trim();if(!player.name||!player.team)return;$("welcomeName").textContent=`Xin chào, ${player.name}!`;round=0;qIndex=0;score=0;done=0;$("score").textContent=0;show("gameView");renderQuestion()}
function finish(){$("resultName").textContent=`${player.name} · ${player.team}`;$("finalScore").textContent=score;$("resultMessage").textContent=score>=350?"Bạn đã chinh phục đấu trường với thành tích ấn tượng!":score>=250?"Một hành trình đáng tự hào. Hãy tiếp tục khám phá lịch sử!":"Cảm ơn bạn đã tham gia. Mỗi lần học là một lần tiến bộ!";show("resultView")}
function reset(){round=0;qIndex=0;score=0;done=0;$("score").textContent=0;show("loginView")}
$("loginForm").addEventListener("submit",e=>{e.preventDefault();start()});$("nextBtn").addEventListener("click",next);$("restartBtn").addEventListener("click",reset);$("playAgain").addEventListener("click",reset);
$("adminOpen").onclick=()=>{$("adminModal").classList.remove("hidden");$("adminError").textContent=""};$("closeModal").onclick=()=>$("adminModal").classList.add("hidden");
$("adminForm").addEventListener("submit",e=>{e.preventDefault();if($("adminUser").value==="admin"&&$("adminPass").value==="tayninh2026"){$("adminModal").classList.add("hidden");setupAdmin();show("adminView")}else $("adminError").textContent="Tên đăng nhập hoặc mật khẩu chưa đúng."});
$("backHome").onclick=()=>show("loginView");
function setupAdmin(){
 $("adminRound").innerHTML=QUIZ.map((r,i)=>`<option value="${i}">${r.name}</option>`).join("");
 updateAdminQuestions();$("adminRound").onchange=updateAdminQuestions;$("adminQuestion").onchange=showAdminQuestion;
 $("adminPrev").onclick=()=>moveAdmin(-1);$("adminNext").onclick=()=>moveAdmin(1);showAdminQuestion();
}
function updateAdminQuestions(){$("adminQuestion").innerHTML=QUIZ[Number($("adminRound").value)].questions.map((q,i)=>`<option value="${i}">Câu ${i+1}</option>`).join("");showAdminQuestion()}
function showAdminQuestion(){let r=Number($("adminRound").value),i=Number($("adminQuestion").value),q=QUIZ[r].questions[i];$("adminTopic").textContent=`${QUIZ[r].name} · ${QUIZ[r].topic}`;$("adminQuestionText").textContent=q[0];$("adminAnswer").textContent=`ĐÁP ÁN ĐÚNG: ${"ABCD"[q[2]]} — ${q[1][q[2]]}`}
function moveAdmin(d){let r=Number($("adminRound").value),i=Number($("adminQuestion").value)+d;if(i<0&&r>0){$("adminRound").value=--r;updateAdminQuestions();i=9}else if(i>9&&r<3){$("adminRound").value=++r;updateAdminQuestions();i=0}else i=Math.max(0,Math.min(9,i));$("adminQuestion").value=i;showAdminQuestion()}
