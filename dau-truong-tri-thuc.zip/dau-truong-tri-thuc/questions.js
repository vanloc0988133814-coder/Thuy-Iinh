// Bộ câu hỏi lịch sử Tây Ninh: 4 vòng, mỗi vòng 10 câu.
window.QUIZ = [
 {name:"Vòng 1 · Khởi động",topic:"KIẾN THỨC CƠ BẢN",questions:[
  ["Tây Ninh thuộc vùng địa lý nào của Việt Nam?",["Đông Nam Bộ","Tây Nguyên","Đồng bằng sông Hồng","Duyên hải Nam Trung Bộ"],0],
  ["Tỉnh lỵ của Tây Ninh là thành phố nào?",["Gò Dầu","Tây Ninh","Trảng Bàng","Hòa Thành"],1],
  ["Ngọn núi nổi tiếng và cao nhất Nam Bộ nằm ở Tây Ninh là núi nào?",["Núi Bà Đen","Núi Chứa Chan","Núi Dinh","Núi Cấm"],0],
  ["Tây Ninh giáp quốc gia nào ở phía tây và tây bắc?",["Lào","Thái Lan","Campuchia","Trung Quốc"],2],
  ["Tòa thánh Cao Đài nổi tiếng nằm ở đâu?",["Tân Biên","Thành phố Tây Ninh","Dương Minh Châu","Bến Cầu"],1],
  ["Dòng sông lớn gắn với địa bàn Tây Ninh là sông nào?",["Sông Hồng","Sông Vàm Cỏ Đông","Sông Hương","Sông Đà"],1],
  ["Hồ Dầu Tiếng được biết đến là công trình gì?",["Hồ thủy điện","Hồ nước ngọt nhân tạo lớn","Cảng biển","Khu bảo tồn biển"],1],
  ["Địa danh nào gắn với căn cứ cách mạng nổi tiếng của Tây Ninh?",["Trung ương Cục miền Nam","Địa đạo Củ Chi","Chiến khu Rừng Sác","Pác Bó"],0],
  ["Tây Ninh là cửa ngõ giao lưu với quốc gia nào?",["Campuchia","Myanmar","Malaysia","Singapore"],0],
  ["Lễ hội truyền thống nổi tiếng tại núi Bà Đen là lễ hội nào?",["Lễ hội vía Bà","Lễ hội đền Hùng","Lễ hội chùa Hương","Lễ hội Gióng"],0]
 ]},
 {name:"Vòng 2 · Khám phá",topic:"ĐỊA DANH & DI SẢN",questions:[
  ["Khu di tích lịch sử quốc gia đặc biệt Căn cứ Trung ương Cục miền Nam thuộc huyện cũ nào?",["Tân Biên","Gò Dầu","Bến Cầu","Trảng Bàng"],0],
  ["Núi Bà Đen có độ cao khoảng bao nhiêu mét?",["986 m","500 m","1.500 m","2.200 m"],0],
  ["Tòa thánh Tây Ninh là công trình tiêu biểu của tôn giáo nào?",["Phật giáo","Cao Đài","Hòa Hảo","Tin Lành"],1],
  ["Hồ Dầu Tiếng có vai trò quan trọng nhất nào sau đây?",["Cấp nước và điều tiết nước","Khai thác dầu khí","Nuôi trồng thủy sản biển","Giao thông hàng hải"],0],
  ["Di tích tháp cổ Bình Thạnh thuộc nền văn hóa nào?",["Óc Eo","Chăm Pa","Đông Sơn","Sa Huỳnh"],1],
  ["Cửa khẩu quốc tế Mộc Bài thuộc địa bàn huyện cũ nào?",["Bến Cầu","Tân Châu","Dương Minh Châu","Tân Biên"],0],
  ["Khu rừng nào ở Tây Ninh được biết đến với hệ sinh thái đa dạng?",["Vườn quốc gia Lò Gò – Xa Mát","Cúc Phương","Tràm Chim","U Minh Thượng"],0],
  ["Địa danh nào gắn với chiến thắng vang dội trong kháng chiến chống Mỹ tại Tây Ninh?",["Tua Hai","Điện Biên Phủ","Ấp Bắc","Đồng Xoài"],0],
  ["Nghề truyền thống nào nổi tiếng ở Trảng Bàng?",["Làm bánh tráng phơi sương","Làm nước mắm","Dệt lụa","Đúc đồng"],0],
  ["Đặc sản bánh canh nổi tiếng của Tây Ninh thường được gọi theo địa danh nào?",["Trảng Bàng","Dầu Tiếng","Tân Biên","Bến Cầu"],0]
 ]},
 {name:"Vòng 3 · Bứt phá",topic:"LỊCH SỬ CÁCH MẠNG",questions:[
  ["Phong trào Đồng khởi ở Tây Ninh diễn ra mạnh mẽ vào giai đoạn nào?",["1959–1960","1930–1931","1945–1946","1975–1976"],0],
  ["Chiến thắng Tua Hai diễn ra vào năm nào?",["1960","1954","1968","1972"],0],
  ["Căn cứ Trung ương Cục miền Nam từng là cơ quan đầu não lãnh đạo cách mạng ở đâu?",["Miền Nam Việt Nam","Miền Bắc Việt Nam","Lào","Campuchia"],0],
  ["Trong kháng chiến chống Mỹ, Tây Ninh có vị trí chiến lược vì lý do nào?",["Là địa bàn nối liền biên giới và vùng căn cứ","Có nhiều cảng biển","Nằm sát thủ đô","Là trung tâm công nghiệp phía Bắc"],0],
  ["Ngày giải phóng miền Nam, thống nhất đất nước là ngày nào?",["30/4/1975","2/9/1945","7/5/1954","19/8/1945"],0],
  ["Ai là người đọc Tuyên ngôn Độc lập ngày 2/9/1945?",["Chủ tịch Hồ Chí Minh","Đại tướng Võ Nguyên Giáp","Phạm Văn Đồng","Trường Chinh"],0],
  ["Mục tiêu của phong trào đấu tranh cách mạng ở Tây Ninh là gì?",["Giành độc lập, thống nhất đất nước","Mở rộng thuộc địa","Phát triển chế độ phong kiến","Tách Tây Ninh khỏi Việt Nam"],0],
  ["Địa đạo An Thới là dấu tích lịch sử thuộc địa bàn tỉnh nào?",["Tây Ninh","Quảng Ninh","Nghệ An","Lâm Đồng"],0],
  ["Lực lượng vũ trang cách mạng ở Tây Ninh đã góp phần vào nhiệm vụ nào?",["Bảo vệ căn cứ và chiến đấu chống xâm lược","Khai phá thuộc địa","Mở rộng lãnh thổ sang nước khác","Kiểm soát tuyến hàng hải"],0],
  ["Di tích lịch sử cách mạng có ý nghĩa quan trọng nhất ở Tây Ninh giúp thế hệ trẻ điều gì?",["Hiểu truyền thống đấu tranh và lòng yêu nước","Chỉ phục vụ vui chơi","Thay thế việc học lịch sử","Chỉ có giá trị kinh tế"],0]
 ]},
 {name:"Vòng 4 · Về đích",topic:"TỰ HÀO TÂY NINH",questions:[
  ["Tây Ninh có đường biên giới trên bộ với quốc gia nào?",["Campuchia","Lào","Trung Quốc","Thái Lan"],0],
  ["Vườn quốc gia Lò Gò – Xa Mát nổi bật với giá trị nào?",["Đa dạng sinh học và hệ sinh thái rừng","Bãi biển và san hô","Sa mạc cát","Núi lửa đang hoạt động"],0],
  ["Bánh tráng phơi sương Trảng Bàng thường ăn kèm với gì?",["Rau rừng và thịt luộc","Hải sản sống","Phô mai","Mì Ý"],0],
  ["Núi Bà Đen còn được gọi bằng tên nào?",["Đệ nhất thiên sơn","Nóc nhà Đông Dương","Núi Ngự","Thiên Cấm Sơn"],0],
  ["Tòa thánh Cao Đài Tây Ninh được khánh thành vào năm nào?",["1955","1945","1975","1986"],0],
  ["Khu di tích Căn cứ Trung ương Cục miền Nam nằm trong khu vực rừng nào?",["Rừng Chàng Riệc","Rừng U Minh","Rừng Cúc Phương","Rừng Sơn Trà"],0],
  ["Tây Ninh có vai trò gì trong tuyến biên giới phía Nam?",["Giao thương, kết nối và bảo vệ biên giới","Trung tâm hàng hải quốc tế","Cửa ngõ sang châu Âu","Trung tâm khai thác than"],0],
  ["Việc bảo tồn di tích lịch sử địa phương góp phần gì?",["Giáo dục truyền thống cho thế hệ sau","Làm mất dấu tích quá khứ","Chỉ tăng diện tích đô thị","Thay thế các hoạt động văn hóa"],0],
  ["Một hành động thiết thực để thể hiện lòng tự hào về lịch sử Tây Ninh là gì?",["Tìm hiểu, gìn giữ và giới thiệu di sản quê hương","Xâm hại di tích","Vứt rác tại khu tham quan","Thờ ơ với lịch sử"],0],
  ["Thông điệp phù hợp nhất của cuộc thi Đấu trường Tri thức là gì?",["Hiểu lịch sử để thêm yêu quê hương","Học lịch sử chỉ để lấy điểm","Chỉ ghi nhớ tên địa danh","Không cần tìm hiểu quá khứ"],0]
 ]}
];